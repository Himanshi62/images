from django.contrib import admin

from .models import TaskZero
from .models import task1
# Register your models here.

admin.site.register(TaskZero)
admin.site.register(task1)